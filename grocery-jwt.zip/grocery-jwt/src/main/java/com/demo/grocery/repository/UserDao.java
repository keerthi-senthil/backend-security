package com.demo.grocery.repository;

import com.demo.grocery.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;

@Repository
public interface UserDao extends CrudRepository<User, String> {
    Optional<User> findUserById(String id);

    void deleteById(String id);
}
