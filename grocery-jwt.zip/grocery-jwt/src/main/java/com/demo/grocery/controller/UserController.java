package com.demo.grocery.controller;

import com.demo.grocery.repository.UserDao;
import com.demo.grocery.model.User;
import com.demo.grocery.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.PostConstruct;
import java.math.BigInteger;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

    @Autowired
    private UserService userService;

    private UserDao userDao;
    @PostConstruct
    public void initRoleAndUser() {
        userService.initRoleAndUser();
    }


    @PostMapping("/registerNewUser")
    public User registerNewUser(@RequestBody User user) {
        return userService.registerNewUser(user);
    }

    @GetMapping("/forAdmin")
    @PreAuthorize("hasRole('Admin')")
    public String forAdmin(){
        return "This URL is only accessible to the admin";
    }

    @GetMapping("/forUser")
    @PreAuthorize("hasRole('User')")
    public String forUser(){
        return "This URL is only accessible to the user";
    }

    @DeleteMapping("/deleteUser/{id}")
    public ResponseEntity<?> deleteUser(@PathVariable("id") String id) {
        userService.deleteById(id);
        return new ResponseEntity<>(HttpStatus.OK);

    }

    @GetMapping("/findUser/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") String id){
        User user=userService.findUserById(id);
        return new ResponseEntity<>(user,HttpStatus.OK);
    }

    @PutMapping("/UpdateUser/{id}")
    public ResponseEntity<User> updateUsers(@PathVariable("id") Long id,@RequestBody User user){
        User update = userService.updateUser(user);
        return new ResponseEntity<>(update, HttpStatus.OK);
    }

    @GetMapping("/getUser")
    public ResponseEntity<List<User>>getAllUser(){
        List<User> user=userService.findAllUser();
        return new ResponseEntity<>(user, HttpStatus.OK);
    }
}
