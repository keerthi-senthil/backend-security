package com.demo.grocery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroceryJwtApplicationTests {

    @Test
    void contextLoads() {
    }

}
